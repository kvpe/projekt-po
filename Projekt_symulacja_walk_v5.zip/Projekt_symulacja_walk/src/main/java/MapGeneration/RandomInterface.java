package MapGeneration;

public interface RandomInterface {

    void randomise(Field field);

}
