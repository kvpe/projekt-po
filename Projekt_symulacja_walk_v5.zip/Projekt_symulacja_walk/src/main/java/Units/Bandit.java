package Units;

public class Bandit extends Unit{
    public Bandit(){
        super(30,40,0);
    }
}
