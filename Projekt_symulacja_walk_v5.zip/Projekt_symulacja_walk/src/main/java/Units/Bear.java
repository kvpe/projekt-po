package Units;

public class Bear extends Unit{
    public Bear(){
        super(1200,200,0); //do ogarniecia
    }
}
