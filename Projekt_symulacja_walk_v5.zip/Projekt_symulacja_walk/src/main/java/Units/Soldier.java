package Units;

public class Soldier extends Unit {
    public Soldier(int size) {
        super(100,45,(float)size/10);
    }
}
