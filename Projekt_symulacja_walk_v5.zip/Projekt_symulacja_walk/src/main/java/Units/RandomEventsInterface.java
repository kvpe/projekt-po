package Units;

public interface RandomEventsInterface {
    void bearAttack(Squad squad);
    void banditsTheft(Squad squad);
    void lostRecruits(Squad squad);
    void herdOfCattle(Squad squad);
    void banditsAttack(Squad squad);
    void muddyGround(Squad squad);
    void foodField(Squad squad);
}
